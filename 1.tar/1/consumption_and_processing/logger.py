import logging
from elasticsearch import Elasticsearch
from datetime import datetime
import os
class Logger:
    _logger = None
    @classmethod
    def get_logger(cls,
                    name=os.getenv("LOGGER_NAME", "muazin_logs"), 
                    es_host=os.getenv("ES_HOST", "http://elasticsearch:9200"), 
                    index=os.getenv("LOG_INDEX", "logs_project_muazin"), 
                    level=logging.DEBUG):
        if cls._logger:
            return cls._logger
        logger = logging.getLogger(name)
        logger.setLevel(level)
        if not logger.handlers:
            es = Elasticsearch(es_host)
            class ESHandler(logging.Handler):
                def emit(self, record):
                    try:
                        es.index(index=index, document={
                            "timestamp": datetime.utcnow().isoformat(),
                            "level": record.levelname,
                            "logger": record.name,
                            "message": record.getMessage()
                    })
                    except Exception as e:
                        print(f"ES log failed: {e}")
            logger.addHandler(ESHandler())
            logger.addHandler(logging.StreamHandler())
        cls._logger = logger
        return logger
